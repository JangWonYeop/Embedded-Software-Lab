#define F_CPU	16000000UL
#include <avr/io.h>		
#include <avr/interrupt.h>	
#include <util/delay.h>

volatile int Num = 0, Num0 = 0, Num1 = 0, Num2 = 0, Num3 = 0;
volatile int OnOff = 1;
volatile int led = 0x0f;
volatile int ledcnt = 4;
volatile int over = 0;

unsigned char LED_DATA[ ]= {
		0x00, // 0
		0x01, // 1 
		0x03, // 2 
		0x07, // 3 
		0x0f, // 4 
		0x1f, // 5 
		0x3f, // 6 
		0x7f, // 7 
		0xff, // 8 
	};

unsigned char FND_DATA[ ]= {
		0x3f, // 0
		0x06, // 1 
		0x5b, // 2 
		0x4f, // 3 
		0x66, // 4 
		0x6d, // 5 
		0x7d, // 6 
		0x27, // 7 
		0x7f, // 8 
		0x6f, // 9 
		0x77, // A 
		0x7c, // B 
		0x39, // C 
		0x5e, // D 
		0x79, // E 
		0x71, // F 
		0x80, // . 
		0x40, // - 
		0x08,  // _
		0x3e,	// U
		0x54,	//n
		0x5c,	// o
		0x5e,	// d
	};

SIGNAL(SIG_INTERRUPT4)
{	
	cli( );
	
	if(OnOff == 0){
		OnOff = 1;
	}
	else{
		OnOff = 0;
	}

	if(Num0 % 2 == 0 && OnOff == 0){
		ledcnt++;
		PORTA = LED_DATA[ledcnt];
	}
	else if(Num0 % 2 == 1 && OnOff == 0){
		ledcnt--;
		PORTA = LED_DATA[ledcnt];
	}

	if(ledcnt == 8){
			OnOff = 0;
			over = 1;
	}
	else if(ledcnt == 0){
			OnOff = 0;
			over = 1;
	}

	sei( );
}

SIGNAL(SIG_INTERRUPT5)
{
	cli( );

	Num = 0;
	over = 0;
	OnOff = 1;
	ledcnt = 4;
	PORTA = LED_DATA[ledcnt];

	sei( );
}

int main(){

	DDRA = 0xff;
	PORTA = led;
		
	DDRE = 0xcf;	
	EICRA = 0x00;
	EICRB = 0x0a;	
	EIMSK = 0x30;	
	SREG |= 1<<7;	

	while(1){
			if(OnOff == 1)
				Num++;

			if(over == 0){
			Num3 = (Num / 1000) % 10;
			Num2 = (Num / 100) % 10;
			Num1 = (Num / 10) % 10;
			Num0 = Num % 10;

			PORTC = FND_DATA[Num3];
			PORTG = 0x08;	
			_delay_ms(2);
		
			PORTC = FND_DATA[Num2] | FND_DATA[16];
			PORTG = 0x04;
			_delay_ms(3);
		
			PORTC = FND_DATA[Num1];
			PORTG = 0x02;	
			_delay_ms(2);
		
			PORTC = FND_DATA[Num0];
			PORTG = 0x01;
			_delay_ms(3);
			}

			else{
				if(ledcnt == 8){
			PORTC = FND_DATA[14];
			PORTG = 0x08;	
			_delay_ms(2);
		
			PORTC = FND_DATA[19];
			PORTG = 0x04;
			_delay_ms(3);
		
			PORTC = FND_DATA[14];
			PORTG = 0x02;	
			_delay_ms(2);
		
			PORTC = FND_DATA[20];
			PORTG = 0x01;
			_delay_ms(3);
	}
	else if(ledcnt == 0){
			PORTC = 0x00;
			PORTG = 0x08;	
			_delay_ms(2);
		
			PORTC = FND_DATA[21];
			PORTG = 0x04;
			_delay_ms(3);
		
			PORTC = FND_DATA[22];
			PORTG = 0x02;	
			_delay_ms(2);
		
			PORTC = FND_DATA[22];
			PORTG = 0x01;
			_delay_ms(3);
	}
			}
	}
}
