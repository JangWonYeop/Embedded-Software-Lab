#include "includes.h"

#define F_CPU	16000000UL	// CPU frequency = 16 Mhz
#include <avr/io.h>	
#include <util/delay.h>

#define  TASK_STK_SIZE  OS_TASK_DEF_STK_SIZE            
#define  N_TASKS        5


OS_STK          TaskStk[N_TASKS][TASK_STK_SIZE];        

void FndTask(void *data);
void  Task_1(void *data);
void  Task_2(void *data);
void  Task_3(void *data);
void  Task_4(void *data);
OS_EVENT *Sem;
volatile int taskNum = 0;

int main (void)
{
  OSInit();

  OS_ENTER_CRITICAL();
  TCCR0=0x07;  
  TIMSK=_BV(TOIE0);                  
  TCNT0=256-(CPU_CLOCK_HZ/OS_TICKS_PER_SEC/ 1024);   
  OS_EXIT_CRITICAL();
  
  OSTaskCreate(FndTask, (void *)0, (void *)&TaskStk[0][TASK_STK_SIZE - 1], 5);
  OSTaskCreate(Task_1, (void *)0, (void *)&TaskStk[0][TASK_STK_SIZE - 1], 1);  
  OSTaskCreate(Task_2, (void *)0, (void *)&TaskStk[1][TASK_STK_SIZE - 1], 2);
  OSTaskCreate(Task_3, (void *)0, (void *)&TaskStk[1][TASK_STK_SIZE - 1], 3);
  OSTaskCreate(Task_4, (void *)0, (void *)&TaskStk[1][TASK_STK_SIZE - 1], 4);

  OSStart();                         
  
  return 0;
}

void  Task_1(void *data){
	data = data;
	Sem = OSSemCreate(1);
	taskNum = 1;
	OSTimeDlyHMSM(0, 0, 1, 0);
	OSSemPost(Sem);
}
void  Task_2(void *data){
	data = data;
	INT8U	err;
	OSSemPend(Sem, 0, &err);
	taskNum = 2;
	OSTimeDlyHMSM(0, 0, 2, 0);
	OSSemPost(Sem);
}
void  Task_3(void *data){
	data = data;
	INT8U	err;
	OSSemPend(Sem, 0, &err);
	taskNum = 3;
	OSTimeDlyHMSM(0, 0, 3, 0);
	OSSemPost(Sem);
}
void  Task_4(void *data){
	data = data;
	INT8U	err;
	OSSemPend(Sem, 0, &err);
	taskNum = 4;
	OSTimeDlyHMSM(0, 0, 4, 0);
	OSSemPost(Sem);
}

void FndTask (void *data)
{
    unsigned char FND_DATA[ ]= {
		0x3f, // 0
		0x06, // 1 
		0x5b, // 2 
		0x4f, // 3 
		0x66, // 4 
		0x6d, // 5 
		0x7d, // 6 
		0x27, // 7 
		0x7f, // 8 
		0x6f, // 9 
		0x77, // A 
		0x7c, // B 
		0x39, // C 
		0x5e, // D 
		0x79, // E 
		0x71, // F 
		0x80, // . 
		0x40, // - 
		0x08  // _
	};
    unsigned int num=0, num0, num1, num2, num3;

    data = data;
	
    DDRC = 0xff;	
    DDRG = 0x0f;

    while(1)  {	
		PORTC = 0x00;
		PORTG = 0x08;	
		_delay_ms(2);
			
		PORTC = 0x00;
		PORTG = 0x04;
		_delay_ms(3);
		
		PORTC = 0x00;
		PORTG = 0x02;	
		_delay_ms(2);
		
		PORTC = FND_DATA[tasknum];
		PORTG = 0x01;
		_delay_ms(3);
		
		OSTimeDlyHMSM(0, 0, 0, 10);
    }
}